/*
 * userNode.c
 *
 * Created: 1/2/2023 7:57:47 PM
 *  Author: Erem
 */ 

#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/sleep.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <util/delay.h>
#define DELAY_BACKWARD_COMPATIBLE
#define F_CPU 8000000UL
//#include <util/delay.h>
#define KEY_DDR DDRC //keyboard DDR
#define LCD_CPIN PINB //LCD COMMANDS PIN
#define LCD_CDDR DDRB //LCD COMMANDS DDR
#define KEY_PRT PORTC //keyboard PORT
#define KEY_PIN PINC //keyboard PIN
#define LCD_DPRT PORTA //LCD DATA PORT
#define LCD_DPIN PINA //LCD DATA PIN
#define LCD_CPRT PORTB //LCD COMMANDS PORT
#define LCD_DDDR DDRA //LCD DATA DDR
#define LCD_RS 0 //LCD RS
#define LCD_RW 1 //LCD RW
#define LCD_EN 2 //LCD EN
unsigned char user_nw_ch_read;
unsigned int us1=0;
unsigned char x=1;
unsigned char y=1;
unsigned char keypad[4][3] = { '1','2','3','4','5','6','7','8','9','.','0','#'};
	
	
void usart_init(void)
{
	UCSR0B = (1<<RXEN0)|(1<<RXCIE0) | (1<<TXEN0) | (1<<TXCIE0);
	UCSR0C = (1<<UCSZ01) | (1<<UCSZ00);
	UBRR0L = 0x33;
	UBRR0H=0x0;
	UCSR1B = ((1<<RXEN1)|(1<<RXCIE1) | (1<<TXEN1) | (1<<TXCIE1));
	UCSR1C = (1<<UCSZ01) | (1<<UCSZ00) ;
	UBRR1L = 0x33;
	UBRR1H=0x0;
}


void lcd_gotoxy(unsigned char x, unsigned char y)
{
	char f_ch_add[]={0x80,0xC0,0x94,0xD4};
	lcdCommand(f_ch_add[y-1] + x - 1);
	//_delay_us(100);
}


ISR(USART0_TX_vect){
	UCSR0B &= ~((1 << TXEN0) | (1 << TXCIE0));
}


ISR(USART0_RX_vect) {
	while (!(UCSR0A & (1<<RXC0) )){};
	user_nw_ch_read= UDR0;
	unsigned int user=0;
	if (user_nw_ch_read=='\r')
	{
		y++;
		if (y==5)
		{
			y=1;
			lcdCommand(1);
		}
		lcd_gotoxy(x,y);
	}
	if (user_nw_ch_read=="\r" )
	{
		user++;
	}
	if(user==0 && us1==1 ){
		lcdCommand(1);
		us1=0;
	}
	lcdData(user_nw_ch_read);
}


void lcdCommand( unsigned char cmnd )
{
	LCD_DPRT = cmnd;
	LCD_CPRT &= ~ (1<<LCD_RS);
	LCD_CPRT &= ~ (1<<LCD_RW);
	LCD_CPRT |= (1<<LCD_EN);
	_delay_us(1);
	LCD_CPRT &= ~ (1<<LCD_EN);
	//_delay_us(100);
}


void lcd_init()
{
	LCD_DDDR = 0xFF;
	LCD_CDDR = 0xFF;
	LCD_CPRT &=~(1<<LCD_EN);
	//_delay_us(2000);
	lcdCommand(0x38);
	lcdCommand(0x0E);
	lcdCommand(0x01);
	//_delay_us(2000);
	lcdCommand(0x06);
}


void lcdData( unsigned char data )
{
	LCD_DPRT = data;
	LCD_CPRT |= (1<<LCD_RS);
	LCD_CPRT &= ~ (1<<LCD_RW);
	LCD_CPRT |= (1<<LCD_EN);
	_delay_us(1);
	LCD_CPRT &= ~ (1<<LCD_EN);
	//_delay_us(100);
}


int main(void)
{
	usart_init();
	lcd_init();
	lcd_gotoxy(x,y);
	unsigned char column, row;
	DDRD = 0xFF;
	KEY_DDR = 0xF0;
	KEY_PRT = 0xFF;
	while(1)
	{
		usart_init();
		sei();
		do
		{
			KEY_PRT &= 0x0F;
			column= (KEY_PIN & 0b00000111);
		} while(column != 0b00000111);
		do
		{
			//_delay_ms(20);
			column=(KEY_PIN&0b00000111);
			while(column == 0b00000111){
				//_delay_ms(20);
				column=(KEY_PIN&0b00000111);
			}
			//_delay_ms(20);
			column= (KEY_PIN & 0b00000111);
		}while(column == 0b00000111);
		while(1)
		{
			KEY_PRT = 0xEF; //ground row 0
			column= (KEY_PIN & 0b00000111);
			if(column != 0b00000111)
			{
				row= 0;
				break;
			}
			KEY_PRT = 0xDF;
			column= (KEY_PIN & 0b00000111);
			if(column != 0b00000111)
			{
				row= 1;
				break;
			}
			KEY_PRT = 0xBF;
			column= (KEY_PIN & 0b00000111);
			if(column != 0b00000111)
			{
				row= 2;
				break;
			}
			KEY_PRT = 0x7F;
			column= (KEY_PIN & 0b00000111);
			row= 3;
			break;
		}
		if(column == 0b00000110){
			while(!(UCSR0A & (1<<UDRE0)));
			UDR0=(keypad[row][0]);
		}
		else if(column == 0b00000101){
			while(!(UCSR0A & (1<<UDRE0)));
			UDR0=(keypad[row][1]); //send data
		}
		else if(column == 0b00000011){
			while(!(UCSR0A & (1<<UDRE0)));
			UDR0=(keypad[row][2]);
		}
	}
	return 0 ;
}