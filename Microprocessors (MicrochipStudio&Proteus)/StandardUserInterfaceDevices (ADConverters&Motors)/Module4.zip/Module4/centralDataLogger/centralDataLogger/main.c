/*
 * Module4.c
 *
 * Created: 1/2/2023 7:56:17 PM
 * Author : Erem
 */ 

#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/sleep.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define USER_TR_BUFFER_SIZE 128
#define SENSOR_TR_BUFFER_SIZE 5
#define Reset 0b00000000
#define LogRequest 0b00100000
#define Acknowledge 0b01000000
#define ErrorRepat 0b01100000
unsigned char user_tr_buffer[USER_TR_BUFFER_SIZE] = "";
unsigned char user_tr_index = 0;
unsigned char myList[]= "0123456789ABCDEF";
unsigned char Stack[20];
unsigned char ToS=-1;
unsigned char user_rv_buffer[2];
unsigned char user_rv_index=-1;
unsigned char sensor_rv_buffer[2];
unsigned char sensor_rv_index=-1;
unsigned char new_user_read_char;
unsigned char new_sensor_read_char;
unsigned char sensor_tr_buffer[SENSOR_TR_BUFFER_SIZE] = " ";
unsigned char sensor_tr_index = 0;
unsigned char new_sensor_read_char;
unsigned char cbit;
unsigned char *memadd=0x0500;
unsigned char *memPTR=0x0500;
unsigned char f_temp;
unsigned char s_temp;
unsigned char t_temp;
unsigned char fourth_temp;
unsigned char c_ounter;
unsigned char flag;
unsigned char g_poly= 0b00110101;
unsigned char g_poly2= 0b11010100;
unsigned char try;
void usart_init(void)
{
	UCSR0B = (1<<RXEN0)|(1<<RXCIE0) | (1<<TXEN0) | (1<<TXCIE0);
	UCSR0C = (1<<UCSZ01) | (1<<UCSZ00); // 8 bit data 1 stop bit
	UBRR0L = 0x33; // XTAL = 8 MHz
	UBRR0H=0x0;
	UCSR1B = ((1<<RXEN1)|(1<<RXCIE1) | (1<<TXEN1) | (1<<TXCIE1));
	UCSR1C = (1<<UCSZ01) | (1<<UCSZ00) ;
	UBRR1L = 0x33;
	UBRR1H=0x0;
}
unsigned char crc3(unsigned char temp){
	g_poly= 0b00110101;
	f_temp=0;
	if (temp & (1<<6))
	{
		g_poly= g_poly<< 1;
		f_temp= temp;
		f_temp= f_temp^ g_poly;
		if (f_temp & (1<<5))
		{	g_poly= g_poly>> 1;
			f_temp= f_temp^ g_poly;
			temp = temp + f_temp;
			return temp;
		}
		else{
			temp = temp + f_temp;
			return temp;
		}
	}

	else{
		f_temp= temp;
		if (f_temp & (1<<5))
		{
			f_temp= f_temp^ g_poly;
			temp = temp + f_temp;
			return temp;
		}
		else{
			temp = temp + f_temp;
			return temp;
		}
	}
return temp;
}
unsigned char crc3_check (unsigned char temp){
	f_temp= temp;
	f_temp= crc3(f_temp);
	s_temp=temp;
	s_temp= s_temp& 0b00011111;
	f_temp= f_temp& 0b00011111;
	if(f_temp==s_temp){
		return 1;
	}
	else{
		return 0;
	}
}
unsigned char crc11_check(unsigned char temp,unsigned char f_temp){
	g_poly2= 0b11010100;
	t_temp= f_temp;
	fourth_temp= temp;
	fourth_temp= fourth_temp& 0b11100000;
	int c_ounter;
	for(c_ounter=11;c_ounter>0;c_ounter--)
	{
		if (t_temp & (1<<7))
		{
			t_temp= t_temp^ g_poly2;
		}
		cbit= fourth_temp& (1<<7);
		if (cbit==0b10000000)
		{
			cbit=1;
		}
		else{
			cbit=0;
		}
		fourth_temp= fourth_temp<< 1; //
		t_temp= t_temp<<1;
		t_temp= t_temp+ cbit;
		cbit=0;
	}
	t_temp= t_temp& 0b11111000;
	cbit=0;
	t_temp= t_temp>> 3;
	flag = 0;
	s_temp= temp;
	s_temp= s_temp& 0b00011111;
	if(s_temp== t_temp){
		return 1;
	}
	else{
		return 0;
	}
	return t_temp;
}
//wait until came interrupt
void Sleep_Wait (){
	sleep_enable();
	sei();
	sleep_cpu();
	sleep_disable();
}
void user_buf_tr_init (){
	unsigned char i;
	for(i=0;i<128;i++){
		user_tr_buffer[i]='\0';
	}
	user_tr_index =0;
}
void sen_buf_tr_init (){
	unsigned char i;
	for(i=0;i<5;i++){
		sensor_tr_buffer[i]='\0';
	}
	sensor_tr_index =0;
}
void user_buf_out (unsigned char data){
	while(!(UCSR0A & (1<<UDRE0))); //;
	UDR0=data; //send data
}
void sensor_buf_out (unsigned char data){
	while(!(UCSR1A & (1<<UDRE1)));
	UDR1=data;//send data
}
void init_sensor_rem(void) {
	push(crc3(Reset));
	Sen_Message (Stack[ToS]);
	strcpy(user_tr_buffer, "Sensor initialize\r");
	us_message();
}
void push(unsigned char x){
	ToS++;
	Stack[ToS] =x;
}
unsigned char pop(){
	unsigned char x;
	x=Stack[ToS];
	Stack[ToS]='/0';
	ToS--;
	return x;
}
void Sen_Message (){
	unsigned char i = strlen(sensor_tr_buffer);
	unsigned char j=0;
	while (j<i)
	{
		sensor_buf_out (sensor_tr_buffer[j]);
		j++;
	}
	sen_buf_tr_init ();
}
void us_message(){
	unsigned char i = strlen(user_tr_buffer);
	unsigned char j=0;
	while (j<i)
	{
		user_buf_out (user_tr_buffer[j]);
		j++;
	}
	user_buf_tr_init ();
}
void Req_to_Repeat (void){
	sen_buf_tr_init ();
	ascii_sensor (crc3(ErrorRepat));
	Sen_Message ();
	user_buf_tr_init ();
	strcpy(user_tr_buffer, "Error Repeat go to sensor\r");
	us_message();
}
void DataType(void){
	if(ToS>=0){ //Stack empty
		pop();
	}
	push(new_sensor_read_char);
	user_buf_tr_init ();
	strcpy(user_tr_buffer, "Data packet goes to stack\r");
	us_message();
}
void CommandType(void){
	unsigned char checkFlag =0;
	unsigned char checkIf=0;
	if ((Stack[ToS] & (1<<7)))
	{
		checkFlag= crc11_check(new_sensor_read_char,Stack[ToS]);
		try= new_sensor_read_char;
		if (checkFlag==0)
		{
			pop();
			Req_to_Repeat ();
		}
		else{ // if crc11 pass
			checkIf = new_sensor_read_char & 0b11100000;
			if(checkIf=0b00100000){
				if (memadd==0x18FF)
				{
					memadd =0x0500;
				}
				if (memadd==0x10EB)
				{
					memadd=0x1100;
				}
				memadd++;
				*memadd = Stack[ToS];
				push( crc3(Acknowledge));
				sen_buf_tr_init ();
				ascii_sensor (Stack[ToS]);
				Sen_Message ();
				//User information
				user_buf_tr_init ();
				strcpy(user_tr_buffer, "Stack content has gonesensor(Acknowledge)\r");
				us_message();
			}
		}
	}
	else{
		checkFlag = crc3_check(new_sensor_read_char);
		if (checkFlag==1)
		{
			checkIf = new_sensor_read_char & 0b11100000;
			if (checkIf==0b01000000)
			{
				user_buf_tr_init ();
				strcpy(user_tr_buffer, "Acknowledge is packetin\r");
				us_message();
				if (ToS>=0)
				{
					pop();
				}
			}
			else{
				if (checkIf=0b01100000)
				{
					user_buf_tr_init ();
					strcpy(user_tr_buffer, "Repeat/Error is packet in\r");
					us_message();
					if (ToS>=0)
					{
						sen_buf_tr_init ();
						ascii_sensor (Stack[ToS]);
						Sen_Message ();
						//User informations
						user_buf_tr_init ();
						strcpy(user_tr_buffer, "Stack content has gone sensor\r");
						us_message();
					}
				}
			}
		}
		else{
			Req_to_Repeat ();
		}
	}
}
void MemoryDump(){
	unsigned char x;
	unsigned char temp5;
	memPTR=0x500;
	while(memPTR!=0x10E0){
		user_buf_tr_init ();
		x= *memPTR;
		UsermakeASCII(x);
		us_message();
		memPTR++;
	}
	memPTR=0x1100;
	while(memPTR!=0x18FF){
		user_buf_tr_init ();
		x= *memPTR;
		UsermakeASCII(x);
		us_message();
		memPTR++;
	}
}
void UsermakeASCII(unsigned char x){
	unsigned char temp5;
	temp5 = x >> 4;
	temp5 = temp5 & 0b00001111;
	user_tr_buffer[user_tr_index]=myList[temp5];
	user_tr_index++;
	x = x & 0b00001111;
	user_tr_buffer[user_tr_index]=myList[x];
	user_tr_index++;
	user_tr_buffer[user_tr_index]='\r'; //new line
}
void ascii_sensor (unsigned char x){
	unsigned char temp5;
	temp5 = x >> 4;
	temp5 = temp5 & 0b00001111;
	sensor_tr_buffer[sensor_tr_index]=myList[temp5];
	sensor_tr_index++;
	x = x & 0b00001111; //lest significant byte come
	sensor_tr_buffer[sensor_tr_index]=myList[x];
	sensor_tr_index++;
	sensor_tr_buffer[sensor_tr_index]='\r';
}
void lastEntry(){
	user_buf_tr_init ();
	strcpy(user_tr_buffer,"\r");
	us_message();
	unsigned char x;
	unsigned char t,v;
	x= *memadd;
	user_buf_tr_init ();
	UsermakeASCII(x);
	us_message();
}
//It find ascii value of data
unsigned char findValue(unsigned char asciiValue){
	unsigned char i=0;
	while (i<strlen(myList))
	{
		if (myList[i]==asciiValue)
		return i;
		i++;
	}
}
ISR(USART0_TX_vect){
	if (user_tr_index == 0){
		user_buf_tr_init ();
		UCSR0B &= ~((1 << TXEN0) | (1 << TXCIE0));
	}
}
ISR(USART0_RX_vect) {
	while (!(UCSR0A & (1<<RXC0) )){};
	new_user_read_char = UDR0;
	user_rv_index++;
	user_rv_buffer[user_rv_index]= new_user_read_char;
}
ISR(USART1_TX_vect){
	if (sensor_tr_index == 0){
		sen_buf_tr_init ();
		UCSR1B &= ~((1 << TXEN1) | (1 << TXCIE1));
	}
}
ISR(USART1_RX_vect) {
	while (!(UCSR1A & (1<<RXC1) )){};
	new_sensor_read_char = UDR1;
	sensor_rv_index ++;
	sensor_rv_buffer[sensor_rv_index]=new_sensor_read_char;
	if (sensor_rv_index==1)
	{
		sen_buf_tr_init ();
		strcpy(sensor_tr_buffer,"\r");
		Sen_Message ();
		sen_buf_tr_init ();
		f_temp=findValue(sensor_rv_buffer[0]);
		s_temp= findValue(sensor_rv_buffer[1]);
		f_temp= f_temp<< 4;
		new_sensor_read_char = f_temp+ s_temp;
		f_temp=0;
		s_temp=0;
		f_temp= new_sensor_read_char;
		if (new_sensor_read_char & (1<<7))
		{
			DataType();
		}
		else {
			CommandType();
		}
		sensor_rv_index=-1;
		sen_buf_tr_init ();
		strcpy(sensor_tr_buffer,"\r");
		us_message();
	}
}
void ConfigSlaveWD(){
	if (user_rv_buffer[1]=='A')
	{
		WDTCR= (1<<WDE) | (1<<WDP0); //26.Ms
		user_buf_tr_init ();
		strcpy(user_tr_buffer, "\rWatchdog -30ms\0");
		us_message();
	}
	else if (user_rv_buffer[0]=='B')
	{
		WDTCR= (1<<WDE) | (1<<WDP2);
		user_buf_tr_init ();
		strcpy(user_tr_buffer, "\rWatchdog -250ms\0");
		us_message();
	}
	else if (user_rv_buffer[0]=='C')
	{
		WDTCR= (1<<WDE) | (1<<WDP2) | (1<<WDP0); //470ms
		user_buf_tr_init ();
		strcpy(user_tr_buffer, "\rWatchdog -500ms\0");
		us_message();
	}
}
int main(void)
{
	unsigned char flag=0;
	MCUCR = 0x80;
	XMCRB =(1<<XMM1)|(1<<XMM0);
	ToS=-1; //Stack initialization
	usart_init();
	init_sensor_rem();
	sei();
	while(1){
		usart_init();
		sei();
		//initialization
		Sleep_Wait ();
		if (flag==0)
		{
		if (user_rv_buffer[0]=='1' | user_rv_buffer[0]=='2' |
		user_rv_buffer[0]=='3')
		{
		ConfigSlaveWD();
		user_rv_index=-1;
		flag = 1;
		}
		}
		if (user_rv_index==1)
		{
			if (user_rv_buffer[1]=='.')
			{
				if (user_rv_buffer[0]=='A')
				{
					MemoryDump();
					user_buf_tr_init ();
					strcpy(user_tr_buffer,"\r");
					us_message();
				}
				else if (user_rv_buffer[0]=='B')
				{
					lastEntry();
					user_buf_tr_init ();
					strcpy(user_tr_buffer,"\r");
					us_message();
				}
				else{
					user_buf_tr_init ();
					sen_buf_tr_init ();
					init_sensor_rem();
				}
				user_rv_index=-1;
			}
			else{
				user_rv_index=-1;
			}
		}
		else{
			if (user_rv_buffer[0]=='A' | user_rv_buffer[0]=='B' |
			user_rv_buffer[0]=='C')
			{
				ConfigSlaveWD();
				user_rv_index=-1;
			}
		}
	}
}