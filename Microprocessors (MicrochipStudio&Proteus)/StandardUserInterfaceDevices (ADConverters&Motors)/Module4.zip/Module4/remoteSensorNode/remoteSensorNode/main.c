/*
 * remoteSensorNode.c
 *
 * Created: 1/2/2023 7:58:41 PM
 *  Author: Erem
 */ 

#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include <avr/sleep.h>
#define F_CPU 8000000UL
#define BAUD_RATE 9600
#define Reset 0b00000000
#define LogRequest 0b00100000
#define Acknowledge 0b01000000
#define Error 0b01100000
#define LCD_DPRT PORTD //LCD DATA
#define LCD_DDDR DDRD
#define LCD_DPIN PIND
#define LCD_CPRT PORTA //LCD COMMAND
#define LCD_CDDR DDRA
#define LCD_CPIN PINA
#define LCD_EN 0 //LCD EN
#define LCD_RW 1 //LCD RW
#define LCD_RS 2 //LCD RS
unsigned char T;//temperature
unsigned char M;//moisture
unsigned char WL;// water level
unsigned char BL;
unsigned char sn=0;
unsigned char usartrecieve=0x00;
int motor_open_close= 0;
unsigned char f_crctemp;
unsigned char s_crctemp;


void usart_init()
{
	UCSR0B = (1<<RXEN0)|(1<<RXCIE0) | (1<<TXEN0) | (1<<TXCIE0);
	UCSR0C = (1<<UCSZ01) | (1<<UCSZ00); // 8 bit data 1 stop bit
	UBRR0H = 0x33;
	UBRR0L = 0x0;
}

void sleeptime(){
	sleep_enable();
	sei(); // enable interrupts
	sleep_cpu();
	sleep_disable();
}

void IO_Configuration(){
	DDRB = 0xFF;
	DDRF = 0x00;
	DDRC = 0xFF;
}

unsigned char CRC3(unsigned char f_crctemp){
	unsigned char key2 = 0b00110101;
	s_crctemp=0;
	if (f_crctemp & (1<<6))
	{
		key2 = key2 << 1;
		s_crctemp = f_crctemp;
		s_crctemp = s_crctemp ^ key2;
		if (s_crctemp & (1<<5))
		{
			key2 = key2 >> 1;
			s_crctemp = s_crctemp ^ key2;
			f_crctemp = f_crctemp + s_crctemp;
			return f_crctemp;
		}
		else{
			f_crctemp = f_crctemp + s_crctemp;
			return f_crctemp;
		}
	}
	else{
		s_crctemp = f_crctemp;
		if (s_crctemp & (1<<5))
		{
			s_crctemp = s_crctemp ^ key2;
			f_crctemp = f_crctemp + s_crctemp;
			return f_crctemp;
		}
		else{
			f_crctemp = f_crctemp + s_crctemp;
			return f_crctemp;
		}
	}
}

unsigned char PWNlevel(unsigned char temp){
	unsigned char firstemp;
	unsigned char secondtemp;
	float x;
	switch(temp)
	{
		case 0x02:
		x=20;
		firstemp=255-((255*x)/100);
		return firstemp;
		break;
		case 0x1e:
		x=80;
		firstemp=255-((255*x)/100);
		return firstemp;
		break;
		default:
		temp=firstemp;
		secondtemp=firstemp-1;
		x=secondtemp*2.145;
		firstemp=255-((255*x)/100);
		return firstemp;
	}
}

void startmotor(){
	unsigned char moisturelevel = PWNlevel(M);
	DDRB |= (1<<3);
	DDRB |= (1<<4);
	DDRC =0xFF;
	PORTC=0;
	OCR0 = moisturelevel;
	PORTC=0xFF;
	TCCR0 = 0x64;
}

void init_motor(){
	DDRB |= (1<<4);
	OCR0 = 0;
	TCCR0 = 0x64;
}

void motor_timer(){
	DDRB |= 0x0;
	TCCR1A = 0x00; //00
	TCCR1B = 0x0D; //1D
	OCR1AH = 0x27; //98
	OCR1AL = 0x00; //96
	TIMSK = (1<<OCIE1A);
	sei ();
}

void lcdData( unsigned char data )
{
	LCD_DPRT = data;
	LCD_CPRT |= (1<<LCD_RS);
	LCD_CPRT &= ~ (1<<LCD_RW);
	LCD_CPRT |= (1<<LCD_EN);
	_delay_ms(1);
	LCD_CPRT &= ~ (1<<LCD_EN);
	_delay_ms(1);
}

void lcdCommand( unsigned char command )
{
	LCD_DPRT = command;
	LCD_CPRT &= ~ (1<<LCD_RS)||~ (1<<LCD_RW);
	LCD_CPRT |= (1<<LCD_EN);
	_delay_ms(1);
	LCD_CPRT &= ~ (1<<LCD_EN);
	_delay_ms(1);
}

void SetCursor(unsigned char x, unsigned char y){
	unsigned char f_temp;
	switch(y)
	{
		case 1:
		f_temp=0x80+x-1;
		lcdCommand(f_temp);
		_delay_ms(30);
		break;
		default:
		f_temp=0xC0+x-1;
		lcdCommand(f_temp);
		_delay_ms(30);
	}
}

void lcd_init()
{
	LCD_DDDR = 0xFF;
	LCD_CDDR = 0xFF;
	LCD_CPRT &=~(1<<LCD_EN); //LCD_EN = 0
	_delay_ms(30);
	lcdCommand(0x38);
	lcdCommand(0x0E);
	lcdCommand(0x01);
	_delay_ms(30);
	lcdCommand(0x06);
}

void lcd_print( char * str )
{
	for(unsigned char i = 0; str[i]!='\0';i++)
	{
		_delay_ms(100);
		lcdData(str[i]);
	}
}

void Create_Packetin(unsigned char T,unsigned char M, unsigned char waterlvl,unsigned char batterylvl )
{
	unsigned char t_packet;
	unsigned char m_packet;
	unsigned char w_packet;
	unsigned char b_packet;
	t_packet = T|(1<<7);
	TranCDL(t_packet);
	TranCDL(CRC3(LogRequest));
	m_packet = M|(1<<7)|(1<<5);
	TranCDL(m_packet);
	TranCDL(CRC3(LogRequest));
	w_packet = waterlvl|(1<<7)|(1<<6);
	TranCDL(w_packet);
	TranCDL(CRC3(LogRequest));
	b_packet = batterylvl|(1<<7)|(1<<6)|(1<<5);
	TranCDL(b_packet);
	TranCDL(CRC3(LogRequest));
	sn=1;
}

void ADCconversion (){
	ADCSRA = 0x87;
	ADMUX = 0x20;
	ADCSRA |= (1<<ADSC);
	while ((ADCSRA&(1<<ADIF))==0);
	BL = ADCH;
	BL = BL>>3;
	BL = BL & 0x1F;
	ADMUX++;
	ADCSRA |= (1<<ADSC);
	while ((ADCSRA&(1<<ADIF))==0);
	WL = ADCH;
	WL = WL>>3;
	WL = WL & 0x1F;
	ADMUX++;
	ADCSRA |= (1<<ADSC);
	while ((ADCSRA&(1<<ADIF))==0);
	M = ADCH;
	M = M>>3;
	M = M & 0x1F;
	ADMUX++;
	ADCSRA |= (1<<ADSC);
	while ((ADCSRA&(1<<ADIF))==0);
	T = ADCH;
	T = T>>3;
	T = T & 0x1F;
	Create_Packetin(T,M,WL,BL);
}

unsigned char hexToChar(unsigned char value)
{
	if (value> 0x09)
	value+=0x37;
	else
	value|=0x30;
	return value;
}

void print_data(){
	unsigned char str[8] = " =0x \0";
	_delay_ms(300);
	str[1] = 'T';
	str[5] = hexToChar(T>>4);
	str[6] = hexToChar(T&0x0F);
	lcd_print(str);
	_delay_ms(300);
	SetCursor(1,2);
	str[1] = 'M';
	str[5] = hexToChar(M>>4);
	str[6] = hexToChar(M&0x0F);
	lcd_print(str);
	SetCursor(8,1);
	_delay_ms(300);
	str[1] = 'W';
	str[5] = hexToChar(WL>>4);
	str[6] = hexToChar(WL&0x0F);
	lcd_print(str);
	SetCursor(8,2);
	_delay_ms(300);
	str[1] = 'B';
	str[5] = hexToChar(BL>>4);
	str[6] = hexToChar(BL&0x0F);
	lcd_print(str);
	_delay_ms(1000);
	if(BL<0x14){
		lcd_init();
		lcd_print("change battery");
		SetCursor(1,2);
		lcd_print("immediately!");
	}
}

void TimerADC(){
	TCNT3 = 65534;
	TCCR3A = 0x00;
	TCCR3B = (1<<CS30) | (1<<CS32);;
	TIMSK = (1 << TOIE3) ;
	sei();
}

void TranCDL(unsigned char ch){
	UCSR0B |= (1 << TXEN0) | (1 << TXCIE0);
	while(!(UCSR0A & (1<<UDRE)));
	UDR0 = ch;
}

int main(void)
{
	TranCDL(CRC3(Acknowledge));
	usart_init();
	sei();
	IO_Configuration;
	lcd_init();
	ADCconversion();
	print_data();
	TimerADC();
	init_motor();
	motor_timer();
	while (1)
	{
		if (motor_open_close==0)
		init_motor();
		else
		startmotor();
	}
	return 0;
}

ISR(TIMER1_COMPA_vect) {
	motor_open_close = !motor_open_close;
}

ISR(USART0_TX_vect){
	if (sn== 0){
		UCSR0B &= ~((1 << TXEN0) | (1 << TXCIE0));
	}
}

ISR(USART0_RX_vect) {
	while (!(UCSR0A & (1<<RXC0) )){}; // Double checking flag
	usartrecieve = UDR0;
}

ISR(TIMER3_OVF_vect) {
	lcd_init();
	ADCconversion();
	print_data();
	TCNT3 = 65534;
}



